﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TpPuissance4
{
    class Grille
    {

        
        public Grille()
        {
            Console.WriteLine("Grille cree");
        }

        char[,] grille = new char[6, 7] 
        {
            
            { '1', '1', '1', '1', '1', '1', '1' },
            { '1', '1', '1', '1', '1', '1', '1' },
            { '1', '1', '1', '1', '1', '1', '1' },
            { '1', '1', '1', '1', '1', '1', '1' },
            { '1', '1', '1', '1', '1', '1', '1' },
            { '1', '1', '1', '1', '1', '1', '1' }

        };


        public void Init()
        {

            for (int i=0;i<6;i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    grille[i,j] = ' ';
                }
            }

        }

        public void Afficher()
        {
            /*Console.WriteLine("1   2   3   4   5   6   7    ");
            Console.WriteLine("+---+---+---+---+---+---+---+");
            Console.WriteLine("|0,0|0,1|0,2|0,3|0,4|0,5|0,6|");
            Console.WriteLine("+---+---+---+---+---+---+---+");
            Console.WriteLine("|1,0|1,1|1,2|1,3|1,4|1,5|1,6|");
            Console.WriteLine("+---+---+---+---+---+---+---+");
            Console.WriteLine("|2,0|2,1|2,2|2,3|2,4|2,5|2,6|");
            Console.WriteLine("+---+---+---+---+---+---+---+");
            Console.WriteLine("|3,0|3,1|3,2|3,3|3,4|3,5|3,6|");
            Console.WriteLine("+---+---+---+---+---+---+---+");
            Console.WriteLine("|4,0|4,1|4,2|4,3|4,4|4,5|4,6|");
            Console.WriteLine("+---+---+---+---+---+---+---+");
            Console.WriteLine("|5,0|5,1|5,2|5,3|5,4|5,5|5,6|");
            Console.WriteLine("+---+---+---+---+---+---+---+");
            Console.WriteLine("  1   2   3   4   5   6   7  ");*/


            Console.WriteLine("1   2   3   4   5   6   7    ");
            Console.WriteLine("+---+---+---+---+---+---+---+");

            for(int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 7; j++)
                {

                    Console.Write("| ");
                    Console.Write(grille[i,j]);
                    Console.Write(" ");
                    if (j == 6)
                    {
                        Console.Write("|");
                    }

                }

                Console.WriteLine();
                Console.WriteLine("+---+---+---+---+---+---+---+");

            }

            Console.WriteLine("  1   2   3   4   5   6   7  ");

        }

        public char TestGagner()
        {
            int testeur = 1;

            // Test Ligne
            for(int i = 5; i >= 0; i--)
            {
                for(int j = 1; j < 7; j++)
                {
                    if (grille[i, j] == grille[i,j-1] && grille[i, j]!=' ')
                    {
                        
                        testeur++;
                        //Console.WriteLine("i =" + i + " j =" + j + " testeur=" + testeur);
                        if (testeur == 3)
                        {
                            return grille[i, j];
                        }
                    }
                    else if (grille[i, j] != grille[i, j - 1])
                    {
                       testeur=0;
                    }
                }
                testeur = 1;
            }

            // Test Colonne
            testeur = 1;
            for (int j = 0; j <7; j++)
            {
                for (int i = 1; i < 6; i++)
                {
                    if (grille[i, j] == grille[i-1, j] && grille[i, j] != ' ')
                    {
                        
                        testeur++;
                        //Console.WriteLine("j =" + i + " i =" + j + " testeur=" + testeur);
                        if (testeur == 3)
                        {
                            return grille[i, j];
                        }
                    }
                    else if (grille[i, j] != grille[i-1, j])
                    {
                        testeur = 0;
                    }
                }
                testeur = 1;
            }

            return ' ';
        }

        public int GetLigne(int colonne)
        {
            for (int i=5;i>=0;i--)
            {
                if (grille[i, colonne - 1] == ' ')
                {
                    return i;
                }
            }
            return 0;
        }

        /*public int PlusHauteLigne()
        {
            int[] plusHaut = new int[6];

            for (int i = 0; i < 6; i++)
            {
                plusHaut[i] = GetLigne(i);
            }

            //Rangement(plusHaut);

            if (TableEgale(plusHaut))
            {
                return -1;
            }
            else
            {
                Console.WriteLine("plusHaut[0] : " + plusHaut[0]);
                return plusHaut[0];
            //}
            
        }*/


        public bool TableEgale(int[]table)
        {

            for (int i = 0; i < table.Length; i++)
            {
                for (int j = 1; j < table.Length; j++)
                {
                    if (table[i] == table[j])
                    {
                        
                    }
                    else
                    {
                        return false;
                    }
                }
            }

            return true;
        }


        public void Rangement(int[]table)
        {
            int temp;
            for(int i=0; i < table.Length; i++)
            {
                for (int j = 1; j < table.Length; j++)
                {
                    if (table[i]<table[j])
                    {
                        temp = table[i];
                        table[i] = table[j];
                        table[j] = temp;
                    }
                }
            }
        }


        public void Positionner(int ligne, int colonne, char jeton)
        {
            grille[ligne, colonne-1] = jeton;
        }

        public bool ColonnePleine(int colonne)
        {
            for (int i = 0; i < 6; i++)
            {
                if (grille[i,colonne] == ' ')
                {
                    return false;
                }
            }
            return true;
        }

        public bool GrillePleine()
        {
            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    if (grille[i, j] == ' ')
                    {
                        return false;
                    }
                }
            }
            return true;
        }
    }
}
