﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TpPuissance4
{
    class Jeu
    {
        public Jeu()
        {
            Console.WriteLine("Nouveau jeu créé.");
        }

        public Jeu(string nom)
        {
            this.nom = nom;
            Console.WriteLine("Nouveau jeu ("+ nom +") créé.");
        }


        private string nom;
        public string Nom
        {
            get { return nom; }
            set { nom = value; }
        }

    }
}
