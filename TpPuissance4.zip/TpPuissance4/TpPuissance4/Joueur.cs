﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TpPuissance4
{
    class Joueur
    {
        public string nom;
        public char jeton;
        public Joueur(string nom, char jeton)
        {
            this.nom = nom;
            this.jeton = jeton;
        }

        public int GetColonne()
        {
            string Colonne;
            int colonne;

                Console.WriteLine(this.nom + " a vous de jouer.");
                Console.WriteLine("Choisissez une colonne (1-6)");
                Colonne = Console.ReadLine();
                colonne = int.Parse(Colonne);
                //Console.WriteLine("colonne = "+colonne);
            return colonne;
        }

        public void Jouer(Grille grille)
        {



        }

    }
}
