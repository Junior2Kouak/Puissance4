﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TpPuissance4
{
    class JoueurHumain : Joueur
    {
        public JoueurHumain(string nom, char jeton) : base(nom, jeton)
        {
        }

        public new void Jouer(Grille grille)
        {
            int colonne;
            colonne = GetColonne();  

                

               

            int ligne = grille.GetLigne(colonne);
            //Console.WriteLine("colonne = " + colonne);
            //Console.WriteLine("Ligne = "+ligne);
            grille.Positionner(ligne, colonne,jeton: jeton);
        }

        

    }
}
