﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TpPuissance4
{
    class JoueurIA : Joueur
    {
        public JoueurIA(string nom, char jeton) : base(nom, jeton)
        {
        }

        public new void Jouer(Grille grille)
        {
            int colonne;
            Random aleatoire = new Random();
            colonne = aleatoire.Next(1, 7);

            /*if (grille.PlusHauteLigne()==-1)
            {
                
                colonne = aleatoire.Next(1, 7);
            }
            
            else
            {
                colonne = grille.PlusHauteLigne();
                
            }*/


            Console.WriteLine("Choix IA : "+colonne);
            grille.Positionner(grille.GetLigne(colonne), colonne, this.jeton);
        }
        
    }
}
