﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TpPuissance4
{
    class Program
    {
        static void Main(string[] args)
        {
            Puissance4 puissance4 = new Puissance4();
            puissance4.Demarrer();
            Console.ReadLine();
        }
    }
}
