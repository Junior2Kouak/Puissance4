﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TpPuissance4
{
    class Puissance4 : Jeu
    {
        public void Demarrer()
        {
            string rejouer;
            string adversaire;
            string nomJoueur1;
            char jetonJoueur1 = 'X';
            string nomJoueur2 =" ";
            char jetonJoueur2 = 'O';
            char jetonIA = 'O';
            char vainqueur;
            do
            {
                Console.Clear();
                Console.WriteLine("++++ PUISSANCE4 ++++");
                Console.WriteLine("Menu");
                Console.WriteLine("Choisissez votre adversaire :");
                Console.WriteLine("11. vs Joueur2");
                Console.WriteLine("22. vs Ordinateur");
                Console.WriteLine("A vous de choisir :) : ");
                adversaire = Console.ReadLine();

                
                Console.WriteLine("Entrez nom Joueur1 : ");
                nomJoueur1 = Console.ReadLine();
                JoueurHumain Joueur1 = new JoueurHumain ( nomJoueur1, jetonJoueur1 );
                

                if (adversaire == "11")
                {

                    Console.WriteLine("Entrez nom Joueur2 : ");
                    nomJoueur2 = Console.ReadLine();

                    Console.WriteLine("Joueur1 vs Joueur2");

                }
                JoueurHumain Joueur2 = new JoueurHumain ( nomJoueur2, jetonJoueur2 );
                if (adversaire == "22")
                {
                    Console.WriteLine("Joueur1 vs Ordinateur");
                }
                JoueurIA JoueurIA1 = new JoueurIA ( "IA", jetonIA);


                Grille grille = new Grille();
                grille.Init();

                do
                {
                    Joueur1.Jouer(grille);
                    grille.Afficher();
                    vainqueur = grille.TestGagner();

                    if (adversaire == "11")
                    {
                        Joueur2.Jouer(grille);
                    }
                    if (adversaire == "22")
                    {
                        JoueurIA1.Jouer(grille);
                    }
                    grille.Afficher();

                    vainqueur = grille.TestGagner();
                     

                } while (grille.TestGagner()==' '||grille.GrillePleine()==true);


                Console.WriteLine("---- Fin de la partie ----");
                Console.WriteLine("Bravo "+vainqueur+" a gagne la partie.");

                Console.Write("Voulez-vous rejouer ? (oui/non) : ");
                rejouer = Console.ReadLine();
            } while (rejouer=="oui");
        }
    }
}
